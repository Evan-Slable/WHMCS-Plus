# WHMCS-Plus

WHMCS Plus is a plugin for Firefox that updates the HTML title to show the ticket number and name when viewing tickets in WHMCS. 

Additional features may be added later on to improve functionality. 

## Installation
Click the link [here](https://github.com/Evan-Slable/WHMCS-Plus/blob/main/67789f0f5c7b4def97c4-1.0.xpi) to install

Open the XPI file using Firefox and select the option to Add when it appears on screen.
